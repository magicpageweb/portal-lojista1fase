export function slugify(input: string): string {
  return input
    .toString()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9\s-]/g, "")
    .replace(/\s+/g, "-")
    .replace(/-+/g, "-");
}

export function formatPrice(value: number | null | undefined): string {
  if (value == null) return "";
  return new Intl.NumberFormat("pt-BR", {
    style: "currency",
    currency: "BRL",
  }).format(value);
}

export function formatPhone(raw: string | null | undefined): string {
  if (!raw) return "";
  const digits = raw.replace(/\D/g, "");
  if (digits.length === 11) {
    return `(${digits.slice(0, 2)}) ${digits.slice(2, 7)}-${digits.slice(7)}`;
  }
  if (digits.length === 10) {
    return `(${digits.slice(0, 2)}) ${digits.slice(2, 6)}-${digits.slice(6)}`;
  }
  return raw;
}

export function publicImage(path: string | null | undefined, fallback?: string): string | undefined {
  if (!path) return fallback;
  if (path.startsWith("http")) return path;
  // Public URL pattern for Supabase Storage
  const base = (typeof window !== "undefined" ? "" : "") +
    (import.meta.env.VITE_SUPABASE_URL ?? "");
  if (!base) return fallback;
  return `${base}/storage/v1/object/public/lojistas/${path}`;
}
