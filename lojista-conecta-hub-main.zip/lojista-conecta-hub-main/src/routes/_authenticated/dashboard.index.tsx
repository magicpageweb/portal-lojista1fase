import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { Loader2, Save, Upload, MapPin, MessageCircle, Eye, ExternalLink } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { DashboardShell } from "@/components/dashboard-shell";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { slugify, publicImage } from "@/lib/format";
import { useAuth } from "@/hooks/use-auth";

export const Route = createFileRoute("/_authenticated/dashboard/")({
  component: DashboardPage,
});

function DashboardPage() {
  const { user } = useAuth();
  const qc = useQueryClient();
  const [form, setForm] = useState<any>(null);
  const [saving, setSaving] = useState(false);

  const { data: lojista, isLoading } = useQuery({
    queryKey: ["my-lojista", user?.id],
    enabled: !!user?.id,
    queryFn: async () => {
      const { data } = await supabase.from("lojistas").select("*").eq("user_id", user!.id).maybeSingle();
      return data;
    },
  });

  const { data: cats = [] } = useQuery({
    queryKey: ["categorias"],
    queryFn: async () => (await supabase.from("categorias").select("*").order("ordem")).data ?? [],
  });

  const { data: metrics } = useQuery({
    queryKey: ["my-metrics", lojista?.id],
    enabled: !!lojista?.id,
    queryFn: async () => {
      const { data } = await supabase.from("metricas_lojista").select("tipo").eq("lojista_id", lojista!.id);
      const counts = { visualizacao: 0, clique_whatsapp: 0, acesso_mapa: 0, clique_site: 0 };
      (data ?? []).forEach((m: any) => { counts[m.tipo as keyof typeof counts]++; });
      return counts;
    },
  });

  useEffect(() => {
    if (lojista) setForm(lojista);
    else if (user) setForm({ user_id: user.id, nome_fantasia: "", slug: "" });
  }, [lojista, user]);

  if (isLoading || !form) {
    return <DashboardShell title="Minha loja"><Loader2 className="mx-auto h-6 w-6 animate-spin" /></DashboardShell>;
  }

  const handleChange = (k: string, v: any) => setForm({ ...form, [k]: v });

  const handleUpload = async (file: File, field: "logo_url" | "capa_url") => {
    if (!user) return;
    const ext = file.name.split(".").pop();
    const path = `${user.id}/${field}-${Date.now()}.${ext}`;
    const { error } = await supabase.storage.from("lojistas").upload(path, file, { upsert: true });
    if (error) return toast.error("Erro ao enviar imagem: " + error.message);
    handleChange(field, path);
    toast.success("Imagem enviada");
  };

  const handleSave = async () => {
    if (!form.nome_fantasia) return toast.error("Informe o nome fantasia");
    setSaving(true);
    const slug = form.slug || slugify(form.nome_fantasia);
    const payload: any = { ...form, slug, user_id: user!.id };
    delete payload.id;
    delete payload.created_at;
    delete payload.updated_at;

    const op = lojista?.id
      ? supabase.from("lojistas").update(payload).eq("id", lojista.id)
      : supabase.from("lojistas").insert({ ...payload, status: "aguardando_aprovacao" });

    const { error } = await op;
    setSaving(false);
    if (error) return toast.error(error.message);
    toast.success(lojista?.id ? "Perfil atualizado" : "Cadastro enviado! Aguardando aprovação do Sindilojas.");
    qc.invalidateQueries({ queryKey: ["my-lojista"] });
  };

  const statusLabel: Record<string, { label: string; cls: string }> = {
    aguardando_aprovacao: { label: "Aguardando aprovação", cls: "bg-amber-500/15 text-amber-700" },
    ativo: { label: "Ativo", cls: "bg-emerald-500/15 text-emerald-700" },
    inativo: { label: "Inativo", cls: "bg-muted text-muted-foreground" },
    rejeitado: { label: "Rejeitado", cls: "bg-destructive/15 text-destructive" },
  };
  const st = statusLabel[form.status ?? "aguardando_aprovacao"];

  return (
    <DashboardShell title="Minha loja">
      <div className="mb-6 flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <Badge className={st.cls + " border-0"}>{st.label}</Badge>
          {form.slug && form.status === "ativo" && (
            <Button asChild variant="outline" size="sm">
              <a href={`/lojistas/${form.slug}`} target="_blank" rel="noreferrer">
                Ver loja pública <ExternalLink className="ml-1 h-3 w-3" />
              </a>
            </Button>
          )}
        </div>
        <Button onClick={handleSave} disabled={saving} className="gradient-gold text-secondary shadow-gold">
          {saving ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Save className="mr-2 h-4 w-4" />} Salvar
        </Button>
      </div>

      {metrics && (
        <div className="mb-6 grid gap-3 sm:grid-cols-3">
          <Metric icon={Eye} label="Visualizações" value={metrics.visualizacao} />
          <Metric icon={MessageCircle} label="Cliques WhatsApp" value={metrics.clique_whatsapp} />
          <Metric icon={MapPin} label="Acessos ao mapa" value={metrics.acesso_mapa} />
        </div>
      )}

      <div className="grid gap-6 lg:grid-cols-3">
        <Card className="lg:col-span-2">
          <CardHeader><CardTitle>Dados da loja</CardTitle></CardHeader>
          <CardContent className="grid gap-4 md:grid-cols-2">
            <Field label="Nome fantasia *" value={form.nome_fantasia} onChange={(v) => handleChange("nome_fantasia", v)} />
            <Field label="Razão social" value={form.razao_social} onChange={(v) => handleChange("razao_social", v)} />
            <Field label="CNPJ" value={form.cnpj} onChange={(v) => handleChange("cnpj", v)} />
            <div className="space-y-2">
              <Label>Categoria</Label>
              <Select value={form.categoria_id ?? ""} onValueChange={(v) => handleChange("categoria_id", v)}>
                <SelectTrigger><SelectValue placeholder="Selecione" /></SelectTrigger>
                <SelectContent>
                  {cats.map((c: any) => <SelectItem key={c.id} value={c.id}>{c.nome}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <Field label="Slogan" value={form.slogan} onChange={(v) => handleChange("slogan", v)} className="md:col-span-2" />
            <div className="md:col-span-2 space-y-2">
              <Label>Descrição</Label>
              <Textarea rows={5} value={form.descricao ?? ""} onChange={(e) => handleChange("descricao", e.target.value)} />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader><CardTitle>Imagens</CardTitle></CardHeader>
          <CardContent className="space-y-4">
            <ImageUpload label="Logo" current={form.logo_url} onUpload={(f) => handleUpload(f, "logo_url")} />
            <ImageUpload label="Capa" current={form.capa_url} onUpload={(f) => handleUpload(f, "capa_url")} />
          </CardContent>
        </Card>

        <Card className="lg:col-span-2">
          <CardHeader><CardTitle>Contato e redes</CardTitle></CardHeader>
          <CardContent className="grid gap-4 md:grid-cols-2">
            <Field label="Telefone" value={form.telefone} onChange={(v) => handleChange("telefone", v)} />
            <Field label="WhatsApp (com DDD)" value={form.whatsapp} onChange={(v) => handleChange("whatsapp", v)} />
            <Field label="Email" type="email" value={form.email} onChange={(v) => handleChange("email", v)} />
            <Field label="Site" value={form.site} onChange={(v) => handleChange("site", v)} />
            <Field label="Instagram" value={form.instagram} onChange={(v) => handleChange("instagram", v)} />
            <Field label="Facebook" value={form.facebook} onChange={(v) => handleChange("facebook", v)} />
          </CardContent>
        </Card>

        <Card>
          <CardHeader><CardTitle>Endereço</CardTitle></CardHeader>
          <CardContent className="space-y-4">
            <Field label="Endereço" value={form.endereco} onChange={(v) => handleChange("endereco", v)} />
            <div className="grid grid-cols-2 gap-3">
              <Field label="Número" value={form.numero} onChange={(v) => handleChange("numero", v)} />
              <Field label="CEP" value={form.cep} onChange={(v) => handleChange("cep", v)} />
            </div>
            <Field label="Bairro" value={form.bairro} onChange={(v) => handleChange("bairro", v)} />
            <div className="grid grid-cols-2 gap-3">
              <Field label="Cidade" value={form.cidade} onChange={(v) => handleChange("cidade", v)} />
              <Field label="Estado" value={form.estado} onChange={(v) => handleChange("estado", v)} />
            </div>
          </CardContent>
        </Card>
      </div>
    </DashboardShell>
  );
}

function Field({ label, value, onChange, type = "text", className = "", ...rest }: { label: string; value: any; onChange: (v: string) => void; type?: string; className?: string; [k: string]: any }) {
  return (
    <div className={"space-y-2 " + className}>
      <Label>{label}</Label>
      <Input type={type} value={value ?? ""} onChange={(e) => onChange(e.target.value)} {...rest} />
    </div>
  );
}

function Metric({ icon: Icon, label, value }: any) {
  return (
    <Card>
      <CardContent className="flex items-center gap-3 p-5">
        <span className="grid h-10 w-10 place-items-center rounded-lg bg-primary/10 text-primary">
          <Icon className="h-5 w-5" />
        </span>
        <div>
          <p className="text-2xl font-bold font-display">{value}</p>
          <p className="text-xs text-muted-foreground">{label}</p>
        </div>
      </CardContent>
    </Card>
  );
}

function ImageUpload({ label, current, onUpload }: { label: string; current?: string | null; onUpload: (f: File) => void }) {
  const img = publicImage(current);
  return (
    <div>
      <Label>{label}</Label>
      <label className="mt-2 flex aspect-video cursor-pointer flex-col items-center justify-center overflow-hidden rounded-lg border-2 border-dashed border-border bg-muted/30 transition-colors hover:border-primary">
        {img ? (
          <img src={img} alt="" className="h-full w-full object-cover" />
        ) : (
          <div className="text-center text-muted-foreground">
            <Upload className="mx-auto h-6 w-6" />
            <p className="mt-1 text-xs">Clique para enviar</p>
          </div>
        )}
        <input type="file" accept="image/*" className="hidden" onChange={(e) => e.target.files?.[0] && onUpload(e.target.files[0])} />
      </label>
    </div>
  );
}
