# Portal do Lojista — Sindilojas

## Visão geral
Criar um portal completo com duas frentes: (1) hotsite público para divulgação de lojistas associados e (2) painel administrativo restrito para gestão de perfis, produtos e métricas.

## Fase 1 — Fundação (backend + auth + design system)

### 1.1 Banco de dados
Tabelas necessárias:
- `profiles` — dados do usuário (lojista ou admin)
- `lojistas` — perfil completo da loja (nome, CNPJ, descrição, slogan, segmento, endereço, contatos, redes sociais, status de aprovação)
- `categorias` — segmentos de lojas (Moda, Alimentação, Serviços, etc.)
- `produtos` — catálogo digital por loja (nome, foto, preço, descrição)
- `metricas_lojista` — visualizações, cliques WhatsApp, acessos ao mapa
- `vitrines_especiais` — destaques/lojistas em evidência
- `user_roles` — roles separados (admin, lojista)

RLS em todas as tabelas. GRANTs para authenticated e service_role.

### 1.2 Autenticação
- Email/senha + Google Sign In (padrão Lovable Cloud)
- Sistema de roles (admin vs lojista) via tabela `user_roles` + função `has_role`
- Middleware de bearer token em `src/start.ts`

### 1.3 Design system
- Cores: amarelo-ouro `#F5A623` (primary), azul-marinho `#1A2E5A` (secondary), branco para respiro
- Tipografia: display bold para títulos, sans-serif limpa para corpo
- Tokens CSS no `styles.css` (oklch format)
- Componentes shadcn/ui reutilizáveis

## Fase 2 — Hotsite Público

### 2.1 Estrutura de rotas
- `/` — Home com hero, contadores, destaques
- `/lojistas` — Grid de lojistas com filtros por categoria
- `/lojistas/$slug` — Página individual da loja (catálogo, mapa, contato)
- `/busca` — Busca inteligente por nome, produto ou categoria

### 2.2 Componentes
- Hero section com texto animado rotacionando ("Compre Local", "Apoie o Comércio", "Encontre seu Lojista")
- Grid de cards com flip effect no hover
- Filtro de categorias com transição suave
- Lightbox para produtos
- Contadores animados (associados, produtos, bairros)
- Seção de vitrines especiais
- Busca com autocomplete
- Rodapé com links e selos

### 2.3 SEO
- Schema.org (LocalBusiness, Product, Organization) via JSON-LD
- Meta tags dinâmicas por lojista
- Sitemap XML automático
- Lazy load em imagens

## Fase 3 — Painel Administrativo

### 3.1 Estrutura de rotas (layout `_authenticated`)
- `/login` — Tela de login
- `/dashboard` — Dashboard do lojista (próprio perfil + produtos + métricas)
- `/admin` — Dashboard do admin (visão geral + aprovações + métricas globais)
- `/admin/lojistas` — Gestão de lojistas
- `/admin/aprovacoes` — Fila de aprovação

### 3.2 Funcionalidades
- Upload de logo, fotos da loja e produtos (Storage)
- Formulário completo de perfil
- CRUD de produtos no catálogo
- Status de publicação: ativo / inativo / aguardando aprovação
- Métricas: visualizações, cliques WhatsApp, acessos ao mapa
- Admin: aprovar/rejeitar lojistas, gerenciar vitrines especiais

## Fase 4 — Polimento

- Scroll reveal (fade-in, slide-up)
- Botões com ripple/glow/slide hover
- Cards com sombra elevada no hover
- Microinterações em elementos clicáveis
- 100% responsivo mobile-first
- Contraste AAA, navegação por teclado

## Stack técnico
- TanStack Start v1 (SSR/SSG)
- React 19 + Tailwind CSS v4
- Lovable Cloud (PostgreSQL, Auth, Storage)
- shadcn/ui para componentes base
- Lucide React para ícones
- Framer Motion para animações

## Ordem de entrega sugerida
1. Fase 1 (database + auth + design system)
2. Fase 2 (hotsite público — home + listagem + detalhe)
3. Fase 3 (painel admin — login + dashboards + CRUD)
4. Fase 4 (polimento + SEO + animações)

Aprova para começar pela Fase 1?